package com.example.cpp;

public class Usermodel {
    String AddmisonYear,Branch,Enrolmentnumber,Fullname,HostellUser,Role,lostreport,password;

    public Usermodel() {
    }


    public String getAddmisonYear() {
        return AddmisonYear;
    }

    public void setAddmisonYear(String addmisonYear) {
        AddmisonYear = addmisonYear;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String branch) {
        Branch = branch;
    }

    public String getEnrolmentnumber() {
        return Enrolmentnumber;
    }

    public void setEnrolmentnumber(String enrolmentnumber) {
        Enrolmentnumber = enrolmentnumber;
    }


    public String getFullname() {
        return Fullname;
    }

    public void setFullname(String fullname) {
        Fullname = fullname;
    }

    public String getHostellUser() {
        return HostellUser;
    }

    public void setHostellUser(String hostellUser) {
        HostellUser = hostellUser;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }

    public String getLostreport() {
        return lostreport;
    }

    public void setLostreport(String lostreport) {
        this.lostreport = lostreport;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
