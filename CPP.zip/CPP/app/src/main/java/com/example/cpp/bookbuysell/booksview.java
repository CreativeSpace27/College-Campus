package com.example.cpp.bookbuysell;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.cpp.R;

public class booksview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booksview);
    }
}