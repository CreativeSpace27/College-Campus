package com.example.cpp.hostelladmin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.cpp.R;

public class document_listreqadd_admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_listreqadd_admin);
    }
}