package com.example.cpp.hostelladmin;

public class hostelladminmodel {
    String AddmisionYear,Branch,Enrolmentnumber,Fullname,Description,penalty;

    public hostelladminmodel() {
    }

    public String getAddmisionYear() {
        return AddmisionYear;
    }

    public void setAddmisionYear(String addmisionYear) {
        AddmisionYear = addmisionYear;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String branch) {
        Branch = branch;
    }

    public String getEnrolmentnumber() {
        return Enrolmentnumber;
    }

    public void setEnrolmentnumber(String enrolmentnumber) {
        Enrolmentnumber = enrolmentnumber;
    }

    public String getFullname() {
        return Fullname;
    }

    public void setFullname(String fullname) {
        Fullname = fullname;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getPenalty() {
        return penalty;
    }

    public void setPenalty(String penalty) {
        this.penalty = penalty;
    }
}
